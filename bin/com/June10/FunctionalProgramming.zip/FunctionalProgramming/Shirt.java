package com.June10.FunctionalProgramming;

public class Shirt {
	int price;
	Shirt(int price) {
		super();
		this.price=price;
	}

}
