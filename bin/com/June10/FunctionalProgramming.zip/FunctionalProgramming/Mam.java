package com.June10.FunctionalProgramming;

public class Mam {

	
	public static void main(String[] args) {
		Shirt s=new Shirt(56);
		System.out.println(s.price);
		
}
}